package br.gov.mctic.sepin.automacao.cenario.cadastrarProjetoConveniado;

import org.junit.After;
import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.IncluirProjetoConveniadoPage;

public class InformarPropriedadeIntelectualCenario extends AbstractCenario {

	@Test
	public void alterarProjetoConveniado() {
		selecionarInstituicao("01.573.107/0001-91");
		Em(IncluirProjetoConveniadoPage.class).acessarProjeto("THOREB DO BRASIL SISTEMAS ELETRONICOS LTDA", "Editar");
		Em(IncluirProjetoConveniadoPage.class).informarPropriedadeIntelectual();
		
		
	}
	
	@After
	public void finalizarTeste() {
		finalizarNavegador();
	}
}



