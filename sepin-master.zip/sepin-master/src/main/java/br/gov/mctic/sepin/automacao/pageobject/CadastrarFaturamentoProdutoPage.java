package br.gov.mctic.sepin.automacao.pageobject;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import br.gov.mctic.sepin.automacao.core.AbstractPageObject;
import br.gov.mctic.sepin.automacao.core.WDS;



public class CadastrarFaturamentoProdutoPage extends AbstractPageObject{
	
	/* In�cio IncluirFaturamentoProduto */

	@FindBy(xpath="(//tbody//tr//td//mat-radio-group//mat-radio-button)[1]")
	private WebElement faturamentoIncentivoSimLinha1;
	
	public void acionarOpcaoSimLinha1() {
		faturamentoIncentivoSimLinha1.click();
		
	}

	
	@FindBy(xpath="(//tbody//tr//td//div//mat-icon)[1]")
	private WebElement acoesLinha1;
	
	public void acionarAcoesLinha1() {
		acoesLinha1.click();
	}

	
	@FindBy(xpath="(//mat-radio-group//mat-radio-button//div[@class='mat-radio-container'])[1]")
	private WebElement simAbaProduto;
	
	public void acionarOpcaoSimAbaProduto() {
		simAbaProduto.click();
		simAbaProduto.click();
		
		
	}

	
	@FindBy(xpath="//button//span[contains(text(),'Pr�ximo')]")
	private WebElement produtoProximo;
		
	public void acionarProximoAbaProduto() {
		produtoProximo.click();
		
	}
	
	@FindBy(xpath="//div//app-currency[@controlname='faturamentoBruto']//input")
	private WebElement insereValorFaturamentoBruto;

	public void preencherFaturamentoBruto(String valorFaturamentoBruto) {
		insereValorFaturamentoBruto.clear();
		insereValorFaturamentoBruto.sendKeys(valorFaturamentoBruto);
		
	}
	
	@FindBy(xpath="//div//app-currency[@controlname='exportacoes']//input")
	private WebElement insereValorExportacoes;

	public void preencherExportacoes(String valorExportacoes) {
		insereValorExportacoes.clear();
		insereValorExportacoes.sendKeys(valorExportacoes);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='vendasZfm']//input")
	private WebElement insereValorVendasZFM;
	
	public void preencherVendasZFM(String valorVendasZFM) {
		insereValorVendasZFM.clear();
		insereValorVendasZFM.sendKeys(valorVendasZFM);
		
	}

	
	@FindBy(xpath="//div//input[@formcontrolname='quantidadeProduzida']")
	private WebElement insereValorQuantidadeProduzida;	
		
	public void preencherQuantidadeProduzida(String valorQuantidadeProduzida) {
		insereValorQuantidadeProduzida.clear();
		insereValorQuantidadeProduzida.sendKeys(valorQuantidadeProduzida);
		
	}


	@FindBy(xpath="//div//app-currency[@controlname='ipi']//input")
	private WebElement insereValorIPI;	
	
	public void preencherIPI(String valorIPI) {
		insereValorIPI.clear();
		insereValorIPI.sendKeys(valorIPI);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='pisCofins']//input")
	private WebElement insereValorPISCofins;
	
	public void preencherPISCofins(String valorPISCofins) {
		insereValorPISCofins.clear();
		insereValorPISCofins.sendKeys(valorPISCofins);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='icms']//input")
	private WebElement insereValorICMS;
	
	public void preencherICMS(String valorICMS) {
		insereValorICMS.clear();
		insereValorICMS.sendKeys(valorICMS);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='aquisicoesInformatica']//input")
	private WebElement insereValorAquisicoesBens;
	
	public void preencherAquisicoesBens(String valorAquisicoesBens) {
		insereValorAquisicoesBens.clear();
		insereValorAquisicoesBens.sendKeys(valorAquisicoesBens);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='devolucoes']//input")
	private WebElement insereValorDevolucoes;
	
	public void preencherDevolucoes(String valorDevolucoes) {
		insereValorDevolucoes.clear();
		insereValorDevolucoes.sendKeys(valorDevolucoes);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='incentivoIpi']//input")
	private WebElement insereValorIncentivoIPI;
	
	public void preencherIncentivoIPI(String valorIncentivoIPI) {
		insereValorIncentivoIPI.clear();
		insereValorIncentivoIPI.sendKeys(valorIncentivoIPI);
		
	}

	@FindBy(xpath="//div//app-currency[@controlname='incentivoIcms']//input")
	private WebElement insereValorIncentivoICMS;
	
	public void preencherIncentivoIMCS(String valorIncentivoICMS) {
		insereValorIncentivoICMS.clear();
		insereValorIncentivoICMS.sendKeys(valorIncentivoICMS);
		
	}

	@FindBy(xpath="(//div//button//span[contains(text(),'Pr�ximo')])[2]")
	private WebElement faturamentoProximo;
	
	public void acionarProximoAbaFaturamento() {
		faturamentoProximo.click();
		
	}

	@FindBy(xpath="//mat-radio-button//div[contains(text(),'Sim')]")
	private WebElement produtoTrocouCumprimentoPPBSim; 
	
	public void acionarOpcaoSimAbaTrocaPPB() {
		produtoTrocouCumprimentoPPBSim.click();
		
	}

	@FindBy(xpath="//app-select-portaria[@controlname='portaria']")
	private WebElement portariaTrocaPPBPDI;
	
	public void selecionarPortariaPPB(String selecionarOpcaoPortariaPPB) {
		portariaTrocaPPBPDI.click();
		WDS.delay(1500);
		WDS.get().findElement(By.xpath("//span[text()= '"+ selecionarOpcaoPortariaPPB + "']")).click();

	}

	@FindBy(xpath="//div//app-percent[@controlname='percentualEspecificado']//input")
	private WebElement insereValorPercentualPortaria;
	
	public void preencherPercentualPortaria(String valorPercentualPortaria) {
		insereValorPercentualPortaria.clear();
		insereValorPercentualPortaria.sendKeys(valorPercentualPortaria);
		
	}

	@FindBy(xpath="//mat-checkbox[@formcontrolname='projetoConveniado']")
	private WebElement selecionarCheckProjetoConveniado;

	
	@FindBy(xpath="//app-currency[@controlname='obrigacaoProjetoConveniado']//input")
	private WebElement insereObrigacaoProjetoConveniado;
	
	public void selecionarCheckPreencherProjetoConveniado(String valorObrigacaoProjetoConveniado) {
		
				
		WebElement projetoConveniadoPegarGetAttribute = WDS.get().findElement(By.xpath("//mat-checkbox[@formcontrolname='projetoConveniado']//div//input"));
		projetoConveniadoPegarGetAttribute.getAttribute("aria-checked");
		System.out.println("CheckBox Projeto Conveniado: " + projetoConveniadoPegarGetAttribute.isSelected());
			
		
		if (projetoConveniadoPegarGetAttribute.isSelected()) {
			insereObrigacaoProjetoConveniado.clear();
			insereObrigacaoProjetoConveniado.sendKeys(valorObrigacaoProjetoConveniado);
			
			
		} else {
			selecionarCheckProjetoConveniado.click();
			WDS.delay(500);
			insereObrigacaoProjetoConveniado.clear();
			insereObrigacaoProjetoConveniado.sendKeys(valorObrigacaoProjetoConveniado);
						
		}
		
	}

	@FindBy(xpath="//mat-checkbox[@formcontrolname='projetoProprio']")
	private WebElement selecionarCheckProjetoProprio;
	
	@FindBy(xpath="//app-currency[@controlname='obrigacaoProjetoProprio']//input")
	private WebElement insereObrigacaoProjetoProprio;
	
	
	public void selecionarCheckPreencherProjetoProprio(String valorObrigacaoProjetoProprio) {
		
		WebElement projetoProprioPegarGetAttribute = WDS.get().findElement(By.xpath("//mat-checkbox[@formcontrolname='projetoProprio']//div//input"));
		projetoProprioPegarGetAttribute.getAttribute("aria-checked");
		System.out.println("CheckBox Projeto Pr�prio: " + projetoProprioPegarGetAttribute.isSelected());
		
		if(projetoProprioPegarGetAttribute.isSelected()) {
			insereObrigacaoProjetoProprio.clear();
			insereObrigacaoProjetoProprio.sendKeys(valorObrigacaoProjetoProprio);
		}else {
			
			selecionarCheckProjetoProprio.click();
			WDS.delay(500);
			insereObrigacaoProjetoProprio.clear();
			insereObrigacaoProjetoProprio.sendKeys(valorObrigacaoProjetoProprio);
			
		}
						
		
	}
	@FindBy(xpath="//mat-checkbox[@formcontrolname='fndct']")
	private WebElement selecionarCheckFNDCT;
	
	@FindBy(xpath="//app-currency[@controlname='obrigacaoFndct']//input")
	private WebElement insereObrigacaoFNDCT;

	public void selecionarCheckPreencherFNDCT(String valorObrigacaoFNDCT) {
		
		WebElement fndctPegarGetAttribute = WDS.get().findElement(By.xpath("//mat-checkbox[@formcontrolname='fndct']//div//input"));
		fndctPegarGetAttribute.getAttribute("aria-checked");
		System.out.println("CheckBox FNDCT: " + fndctPegarGetAttribute.isSelected());
		
		
		if(fndctPegarGetAttribute.isSelected()) {
			insereObrigacaoFNDCT.clear();
			insereObrigacaoFNDCT.sendKeys(valorObrigacaoFNDCT);
		}else {
			selecionarCheckFNDCT.click();
			WDS.delay(500);
			insereObrigacaoFNDCT.clear();
			insereObrigacaoFNDCT.sendKeys(valorObrigacaoFNDCT);
		}
		
		
	}
	
	

	@FindBy(xpath="//mat-checkbox[@formcontrolname='ppi']")
	private WebElement selecionarCheckPPI;
	
	@FindBy(xpath="//app-currency[@controlname='obrigacaoPpi']//input")
	private WebElement insereObrigacaoPPI;
	
	public void selecionarCheckPreencherPPI(String valorObrigacaoPPI) {
		
		WebElement ppiPegarGetAttribute = WDS.get().findElement(By.xpath("//mat-checkbox[@formcontrolname='ppi']//div//input"));
		ppiPegarGetAttribute.getAttribute("aria-checked");
		System.out.println("CheckBox PPI: " + ppiPegarGetAttribute.isSelected());
		
		
		if(ppiPegarGetAttribute.isSelected()) {
			insereObrigacaoPPI.clear();
			insereObrigacaoPPI.sendKeys(valorObrigacaoPPI);
		}else {
			selecionarCheckPPI.click();
			WDS.delay(500);
			insereObrigacaoPPI.clear();
			insereObrigacaoPPI.sendKeys(valorObrigacaoPPI);
		}
		
		
		
		
	}

	@FindBy(xpath="//div//span[contains(text(),'Salvar')]")
	private WebElement botaoSalvarFaturamentoProduto;
	
	public void acionarSalvarFaturamentoProduto() {
		
		botaoSalvarFaturamentoProduto.click();
		//WDS.get().findElement(By.xpath("//div//span[contains(text(),'Salvar')]")).click();
		
	}
	
	/* Fim IncluirFaturamentoProduto */
	
	
	/* In�cio VisualizarFaturamentoProduto */
	
	public void exibicaoNomeEmpresa() {
		try {
			boolean nomeEmpresaExibido = WDS.get().getPageSource().contains("81.243.735/0001-48 - POSITIVO");
			assertTrue(nomeEmpresaExibido);
			System.out.println("Empresa encontrada: 81.243.735/0001-48 - POSITIVO TECNOLOGIA S.A.");
		}catch(AssertionError e){
			System.out.println("ERRO! Empresa n�o encontrada!");
			
		}
	
	}

	/* Fim VisualizarFaturamentoProduto */
	
	
	/* In�cio AlterarFaturamentoProduto */
	
	@FindBy(xpath="//div[@class='toast-message ng-star-inserted']")
	private WebElement mensagemSucessoCadastro;
	
	public void mensagemSucessoCadastrarAlterar(String mensagemSucesso) {
		try {
			Assert.assertEquals(mensagemSucesso, mensagemSucessoCadastro.getText());
			System.out.println("Cadastro/Altera��o realizada com sucesso!");
			
		}catch(AssertionError e){
			System.out.println("ERRO!!! Cadastro/Altera��o n�o realizado!");
			
		}
		
			
	}

	/* Fim AlterarFaturamentoProduto */

}
