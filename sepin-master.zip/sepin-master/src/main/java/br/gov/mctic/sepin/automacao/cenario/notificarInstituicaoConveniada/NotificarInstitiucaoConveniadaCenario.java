package br.gov.mctic.sepin.automacao.cenario.notificarInstituicaoConveniada;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.NotificarInstituicaoConveniadaPage;

public class NotificarInstitiucaoConveniadaCenario extends AbstractCenario {

	@Test
	public void NotificarInstituicaConveniada() {

		selecionarEmpresa("00.954.716/0002-09");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarBotaoRDA(); // Clicar no RDA
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarProjetoConveniado(); // Clicar no projeto do conveniado
		aguardarCarregamento();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarNotificarInstituicao(); // Clicar bot�o Notificar Institui��o
		aguardarCarregamento();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirSigla("TST003"); // Informar a sigla
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirNome("Teste Geovanne 616"); // Informar o nome
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).selecionarRegiao(); // Selecionar a regi�o
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirRegiao(); // Inserir a regi�o
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).selecionarInstituicao();// Selecionando a institui��o
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirInstituicao(); // Informar a Institui��o
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirEncubadora("TESTE  AUTOM. 001");// Informar Empresa																				// Encubadora
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirDataInicial("01/01/2019"); // Informar a data inicio
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirDataFinal("01/12/2019"); // Informar a data fim
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).selecionarTP();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirTP(); // Informar o Tipo
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarSim(); // Informar o projeto
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarEnviar(); // Clicar em enviar

	}

}
