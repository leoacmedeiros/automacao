package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoProduto;


import org.junit.Test;
import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadastrarFaturamentoProdutoPage;


public class IncluirFaturamentoProduto extends AbstractCenario{

	//Estar vinculado na seguinte empresa
	//Empresa: 81.243.735/0001-48 - POSITIVO TECNOLOGIA S.A.
	
	@Test
	public void ct085_IncluirFaturamentoProduto() {
		acessarMenu("RDA","Faturamento do Produto");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimLinha1();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarAcoesLinha1();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimAbaProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarProximoAbaProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).preencherFaturamentoBruto("5000000000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherExportacoes("1000000000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherVendasZFM("1000000000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherQuantidadeProduzida("100");
		Em(CadastrarFaturamentoProdutoPage.class).preencherIPI("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherPISCofins("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherICMS("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherAquisicoesBens("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherDevolucoes("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherIncentivoIPI("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherIncentivoIMCS("500000");
		Em(CadastrarFaturamentoProdutoPage.class).acionarProximoAbaFaturamento();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimAbaTrocaPPB();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarPortariaPPB("131");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).preencherPercentualPortaria("4");
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherProjetoConveniado("100000000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherProjetoProprio("90000000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherFNDCT("9000000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherPPI("900000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarSalvarFaturamentoProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).mensagemSucessoCadastrarAlterar("Opera��o realizada com sucesso!");
				
	}

}
