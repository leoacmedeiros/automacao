package br.gov.mctic.sepin.automacao.pageobject;

import java.util.List;
import java.util.concurrent.Delayed;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.core.WDS;

public class CadstrarProjetoProprioPage extends AbstractCenario {

	@FindBy(xpath = "//a[@class='mat-stroked-button']")
	public WebElement botaoIncluiProjeto;

	public void incluirProjeto() {
		botaoIncluiProjeto.click();
	}

	@FindBy(xpath = "//div/div[span/label/mat-label[contains(text(),'Nome')]]/input")
	public List<WebElement> campoNome;

	public void informarNome(String nome) {
		campoNome.get(0).sendKeys(nome);
		campoNome.get(0).sendKeys(Keys.TAB);
	}

//	@FindBy(id = "//mat-label[contains(text(),'Sigla')]/../../../input")
	@FindBy(xpath= "//input[@formcontrolname='sigla']")
	private WebElement camposigla;

	public void informarSigla(String sigla) {
		camposigla.clear();
		camposigla.sendKeys(sigla);
		camposigla.sendKeys(Keys.TAB);
	}
		
		
	

	@FindBy(id = "mat-input-6")
	private WebElement clicarsigla;

	public void clicarSigla() {
		clicarsigla.click();

	}

	@FindBy(xpath = "//input[@formcontrolname='dataInicio']")
	private WebElement campoDataIncio;

	public void informarDataIncio(String data) {

		campoDataIncio.sendKeys(data);
		campoDataIncio.sendKeys(Keys.TAB);
	}

	@FindBy(xpath = "//input[@formcontrolname='dataFim']")
	private WebElement campoDataFim;

	public void informarDataFim(String data) {

		campoDataFim.sendKeys(data);
		campoDataFim.sendKeys(Keys.TAB);
	}

	@FindBy(xpath = "//div/app-select-tipos-projeto/mat-select")
	public WebElement clicarCombo;

	public void SelecionarcomboTipo() {
		clicarCombo.click();

	}

	public void selcionaropcao(String opcao) {
		WebElement novaopcao = WDS.get().findElement(By.xpath("//mat-option[span[contains(text(),'" + opcao + "')]]"));
		WDS.delay(30);
		novaopcao.click();

	}

	public void SelcionarRadio(String opcao) {
		WDS.get().findElement(By.xpath("//mat-radio-button//div[contains(text(),'" + opcao + "')]//../..")).click();
		//WDS.delay();
		//WDS.get().findElement(By.xpath("//mat-radio-button//div[contains(text(),'" + opcao + "')]//../..")).click();
	}

	@FindBy(xpath = "//input[@formcontrolname='cpf']")
	public WebElement informarCPF;

	public void informarCPF(String cpf) {

		informarCPF.sendKeys(cpf);
		informarCPF.sendKeys(Keys.TAB);

	}

	@FindBy(xpath= "//input[@formcontrolname='telefone']")
	public WebElement informatelefone;

	public void informarTelefone(String telefone) {
		informatelefone.sendKeys(telefone);
		informatelefone.sendKeys(Keys.TAB);

	}

	@FindBy(xpath = "//input[@formcontrolname='email']")
	public WebElement informaemail;

	public void informarEmail(String email) {

		informaemail.sendKeys(email);
		informaemail.sendKeys(Keys.TAB);

	}


	public void selcionarCheck(String opcao) {
		WDS.get().findElement(By.xpath(
				"//mat-checkbox//div/../span[@class = 'mat-checkbox-label'][contains(text(),'" + opcao + "')]/../.."))
				.click();
	}

	@FindBy(xpath = "//div/input[@id='mat-input-14']")
	public WebElement informararea;

	public void informarArea(String area) {

		informararea.sendKeys(area);
		

	}

	@FindBy(xpath = "//mat-option//span[contains(text(),'tecnologia')]")
	public WebElement selecionararea;

	public void selecionarArea() {
		selecionararea.click();

	}




	public void SelecionarRadioAbangenciaDesenvolvimento(String opcao) {

		WDS.get().findElement(By.xpath("//mat-radio-button/label[div[contains(text(),'" + opcao + "')]]/div")).click();
		WDS.get().findElement(By.xpath("//mat-radio-button/label[div[contains(text(),'" + opcao + "')]]/div")).click();

	}

	@FindBy(xpath = "//input[@id='mat-input-14']")
	WebElement infArea;



	@FindBy(xpath = "//input[@formcontrolname='atividadeEconomica']")
	WebElement clicarArea;

	public void limparArea() {
		clicarArea.clear();
		aguardarCarregamento();

	}

	public void informaArea(String opcao) {

		clicarArea.sendKeys(opcao);
		aguardarCarregamento();
		WDS.get().findElement(By.xpath("//mat-option/span[contains(text(),'" + opcao + "')]")).click();

	}

	public void propriedadeintelectualRadio(String opcao) {
		WDS.get().findElement(By.xpath(
				"//div/app-radio-sim-nao[@controlname='gerouPropriedadeIntelectual']/mctic-radio-button/div/mat-radio-group/mat-radio-button//div[@class='mat-radio-label-content'][contains(text(),'"
						+ opcao + "')]"))
				.click();
		WDS.get().findElement(By.xpath(
				"//div/app-radio-sim-nao[@controlname='gerouPropriedadeIntelectual']/mctic-radio-button/div/mat-radio-group/mat-radio-button//div[@class='mat-radio-label-content'][contains(text(),'"
						+ opcao + "')]"))
				.click();

	}

	public void possuiPublicacaoRadio(String opcao) {
		WDS.get().findElement(By.xpath(
				"//div/app-radio-sim-nao[@controlname='possuiPublicacao']/mctic-radio-button/div/mat-radio-group/mat-radio-button//div[@class='mat-radio-label-content'][contains(text(),'"
						+ opcao + "')]"))
				.click();
		WDS.get().findElement(By.xpath(
				"//div/app-radio-sim-nao[@controlname='possuiPublicacao']/mctic-radio-button/div/mat-radio-group/mat-radio-button//div[@class='mat-radio-label-content'][contains(text(),'"
						+ opcao + "')]"))
				.click();

	}

	public void selcionarBotao(String botao) {
		WDS.get().findElement(By.xpath("//button//span[contains(text(),'" + botao + "')]/..")).click();

	}


	@FindBy(xpath = "//div/textarea[@formcontrolname='objetivo']")
	public WebElement escreverObjetivo;

	public void informarObjetivo(String objetivo) {
		escreverObjetivo.clear();
		escreverObjetivo.sendKeys(objetivo);
		escreverObjetivo.sendKeys(Keys.TAB);
	}

	@FindBy(xpath = "//div/textarea[@formcontrolname='etapa']")
	public WebElement escreverDescricao;

	public void informarDescricao(String descricao) {
		escreverDescricao.clear();
		escreverDescricao.sendKeys(descricao);
		escreverDescricao.sendKeys(Keys.TAB);
	}

	@FindBy(xpath = "//div/textarea[@formcontrolname='resultadoObtido']")
	public WebElement escreverResultado;

	public void informarResultado(String resultado) {
		escreverResultado.clear();
		escreverResultado.sendKeys(resultado);
		escreverResultado.sendKeys(Keys.TAB);
	}

	@FindBy(xpath = "// input[@ng-reflect-name='identificacao']")
	public WebElement ecreververIdentificacao;

	public void informarIdentificacao(String id) {

		ecreververIdentificacao.sendKeys(id);
		ecreververIdentificacao.sendKeys(Keys.TAB);

	}

	@FindBy(xpath = "// input[@ng-reflect-name='sigla']")
	public WebElement ecreververSigla;

	public void informarSiglaP(String sigla) {

		ecreververSigla.sendKeys(sigla);
		ecreververSigla.sendKeys(Keys.TAB);

	}

	@FindBy(xpath = "// input[@ng-reflect-name='nome']")
	public WebElement ecreververNome;

	public void informarNomeP(String nome) {

		ecreververNome.sendKeys(nome);
		ecreververNome.sendKeys(Keys.TAB);
	}

	@FindBy(xpath = "//td[5][@role='gridcell']")
	public WebElement clicaropcao;

	public void selecionarOpcao() {
		clicaropcao.click();
	}

	@FindBy(xpath = "//button//mat-icon[contains(text(),'close')]")
	public WebElement clicarclose;

	public void selecionarclose() {
		clicarclose.click();
	}

	public void validarTituloTela(String mensagem) {
		WebElement campo = WDS.get().findElement(By.xpath("//mat-toolbar/span"));
		// System.out.println(campo.getText());
		Assert.assertEquals(mensagem, campo.getText());

	}
	
	public void validarMensagemSucesso(String mensagem) {
		WebElement campo1 = WDS.get().findElement(By.xpath("//div[@role='alertdialog']"));
		//System.out.println(campo.getText());
		Assert.assertEquals(mensagem, campo1.getText());
	}
	
	public void validaResultado(String mensagem) {
		WebElement campo2 = WDS.get().findElement(By.xpath("//tr/td[2]"));
		System.out.println(campo2.getText());
		
}
}