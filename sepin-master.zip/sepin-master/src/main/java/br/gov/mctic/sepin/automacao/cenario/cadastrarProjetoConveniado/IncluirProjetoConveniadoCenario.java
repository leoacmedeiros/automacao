package br.gov.mctic.sepin.automacao.cenario.cadastrarProjetoConveniado;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.IncluirProjetoConveniadoPage;

public class IncluirProjetoConveniadoCenario extends AbstractCenario {
	String nomeProjeto = "TA02 - Teste Automatizado 02";

	@Test
	public void incluirProjetoConveniado() {
		selecionarInstituicao("01.573.107/0001-91");
		Em(IncluirProjetoConveniadoPage.class).acessarProjeto(nomeProjeto, "Editar");
		Em(IncluirProjetoConveniadoPage.class).informarResponsavelProjeto("70033574103");
		Em(IncluirProjetoConveniadoPage.class).informarTelefone("Celular", "telefone", "61991032835");
		Em(IncluirProjetoConveniadoPage.class).informarEmail("email", "deboranwa@gmail.com");
		Em(IncluirProjetoConveniadoPage.class).selecionarAlcance("Na Institui��o");
		Em(IncluirProjetoConveniadoPage.class).selecionarAlcance("No Mercado Interno");
		Em(IncluirProjetoConveniadoPage.class)
				.selecionarAbrangencia("Novo para a empresa, mas existente no mercado nacional;");
		Em(IncluirProjetoConveniadoPage.class).selecionarDesenvoltimento("Desenvolvimento de algo novo");
		Em(IncluirProjetoConveniadoPage.class).atividadeEconomica("atividadeEconomica", "tecnologia");
		Em(IncluirProjetoConveniadoPage.class).gerouProPriedadeIntelectualNao();
		Em(IncluirProjetoConveniadoPage.class).projetoPossuiPublicacaoNao();
		Em(IncluirProjetoConveniadoPage.class).selecionarArtigo("I - trabalho te�rico ou experimental realizado ");
		botaoAvancar("Avan�ar");
		aguardarCarregamento();
		Em(IncluirProjetoConveniadoPage.class).informarObjetivo("objetivo", "Validar Teste Automatizado - Objetivo");
		Em(IncluirProjetoConveniadoPage.class).informarDescricaoEtapas("etapa",
				"Validar Teste Automatizado - Descricao da Etapa");
		Em(IncluirProjetoConveniadoPage.class).informarResultadoObtido("resultadoObtido",
				"Validar Teste Automatizado - Resultado obtido");
		botaoAvancar("Salvar");
		aguardarCarregamento();
		Em(IncluirProjetoConveniadoPage.class).custoIncorrido("0,00");
		Em(IncluirProjetoConveniadoPage.class).valorTotalRepassadoInstituicao("150,00");
		Em(IncluirProjetoConveniadoPage.class).valorAntecipadoProximoAno("250,00");
		Em(IncluirProjetoConveniadoPage.class).valorAntecipadoAnoAnterior("500,00");
		botaoAvancar("Salvar");
		aguardarCarregamento();
		exibeMensagem("Opera��o realizada com sucesso!");

	}

	@After
	public void finalizarTeste() throws SQLException {
		Em(IncluirProjetoConveniadoPage.class).limparDadosDeTeste(nomeProjeto);
		finalizarNavegador();
	}
}
