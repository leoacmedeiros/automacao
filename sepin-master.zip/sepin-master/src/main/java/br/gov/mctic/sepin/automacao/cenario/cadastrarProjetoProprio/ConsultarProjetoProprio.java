package br.gov.mctic.sepin.automacao.cenario.cadastrarProjetoProprio;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadstrarProjetoProprioPage;

public class ConsultarProjetoProprio extends AbstractCenario {
	
	@Test
	public void consultarProjeto (){
		
		acessarMenu("RDA", "Projeto Pr�prio");
		aguardarCarregamento();
		Em(CadstrarProjetoProprioPage.class).informarSiglaP("TST");
		Em(CadstrarProjetoProprioPage.class).informarNomeP("TESTE");
		aguardarCarregamento();
		Em(CadstrarProjetoProprioPage.class).selcionarBotao("Consultar");
		Em(CadstrarProjetoProprioPage.class).validaResultado("TST1 - TESTE1");
		//finalizarNavegador();
		
	}

}
