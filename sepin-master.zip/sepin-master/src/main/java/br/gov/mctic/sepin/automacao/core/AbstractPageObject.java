package br.gov.mctic.sepin.automacao.core;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AbstractPageObject {

	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement campoMensagem;

	public void exibeMensagem(String mensagemEsperada) {
		Assert.assertEquals(mensagemEsperada, campoMensagem.getText());
	}

	protected void aguardarCarregamento() {
		WDS.delay(1000);
		WDS.getWait().until(ExpectedConditions.invisibilityOf(WDS.get().findElement(By.tagName("mctic-loading"))));
	}

	protected void radio(String opcao) {
		aguardarCarregamento();
		WebElement radioButon = WDS.get()
				.findElement(By.xpath("//mat-radio-button//div[contains(text(),'" + opcao + "')]//../.."));
		radioButon.click();
	}

	protected void input(String campo, String valor) {
		WebElement campoInput = WDS.get().findElement(By.xpath("//input[@formcontrolname='" + campo + "']"));
		campoInput.sendKeys(valor);
	}

	protected void inputDispendioRepassado(String campo, String valor) {
		WebElement campoInput = WDS.get().findElement(By.xpath("//app-currency[@controlname='" + campo + "']//input"));
		if (campoInput.toString().isEmpty()) {
			campoInput.sendKeys(valor);
		} else {
			campoInput.clear();
			campoInput.sendKeys(valor);
		}

	}

	protected void textArea(String campo, String valor) {
		WebElement campoInput = WDS.get().findElement(By.xpath("//textarea[@formcontrolname='" + campo + "']"));
		if (campoInput.toString().isEmpty()) {
			campoInput.sendKeys(valor);
		} else {
			campoInput.clear();
			campoInput.sendKeys(valor);
		}

	}

	@FindBy(className = "mat-checkbox-checked")
	private WebElement checkChecked;

	protected void checkbox(String opcao) {
		WebElement check = WDS.get()
				.findElement(By.xpath("//mat-checkbox//span[contains(text(),'" + opcao + "')]/../.."));
		boolean checkChecked = check.getAttribute("class").contains("mat-checkbox-checked");
		if (checkChecked == true) {
			check.click();
			check.click();
		} else {
			check.click();
		}
	}

	protected void option(String valor) {
		WebElement selecionar = WDS.get().findElement(By.xpath("//mat-option//span[contains(text(),'" + valor + "')]"));
		aguardarCarregamento();
		selecionar.click();
	}

}
