package br.gov.mctic.sepin.automacao.cenario.cadastrarProjetoProprio;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadstrarProjetoProprioPage;

public class InformaPropriedadeIntelectual extends AbstractCenario {
 
	@Test

public void informarPropriedade() {
	//aguardarCarregamento();
	//aguardarCarregamento();
	//acessarMenu("RDA", "Projeto Pr�prio");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).incluirProjeto();
	Em(CadstrarProjetoProprioPage.class).informarSigla("TST");
	Em(CadstrarProjetoProprioPage.class).informarNome("TESTE");
	Em(CadstrarProjetoProprioPage.class).informarDataIncio("01/02/2018");
	Em(CadstrarProjetoProprioPage.class).informarDataFim("01/02/2020");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelecionarcomboTipo();
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selcionaropcao("Software");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelcionarRadio("N�o");
	Em(CadstrarProjetoProprioPage.class).informarCPF("03321209101");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelcionarRadio(" Fixo ");
	Em(CadstrarProjetoProprioPage.class).informarTelefone("6133845177");
	Em(CadstrarProjetoProprioPage.class).informarEmail("Kelly.cavalcante@ctis.com");
	Em(CadstrarProjetoProprioPage.class).selcionarCheck("Exporta��o");
	Em(CadstrarProjetoProprioPage.class).selcionarCheck("Na Institui��o");
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelecionarRadioAbangenciaDesenvolvimento(" Novo no mercado Nacional, mas j� existente no mercado mundial; ");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelecionarRadioAbangenciaDesenvolvimento(" Desenvolvimento de algo novo. ");
	Em(CadstrarProjetoProprioPage.class).propriedadeintelectualRadio("Sim");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selcionarBotao(" Informar Propriedade Intelectual ");
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).validarTituloTela("Cadastrar Propriedade Intelectual");
	finalizarNavegador();
	
	
}
}