package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoProduto;

import static org.junit.Assert.*;

import org.junit.Test;
import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadastrarFaturamentoProdutoPage;

public class VisualizarFaturamentoProduto extends AbstractCenario{

	//Estar vinculado na seguinte empresa
	//Empresa: 81.243.735/0001-48 - POSITIVO TECNOLOGIA S.A.
	
	@Test
	public void ct085_VisualizarFaturamentoProduto() {
		
		//acessarMenu("RDA","Faturamento do Produto");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimLinha1();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarAcoesLinha1();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).exibicaoNomeEmpresa();
		Em(CadastrarFaturamentoProdutoPage.class).acionarProximoAbaProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).exibicaoNomeEmpresa();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarProximoAbaFaturamento();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).exibicaoNomeEmpresa();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarSalvarFaturamentoProduto();
		finalizarNavegador();
	}

}
