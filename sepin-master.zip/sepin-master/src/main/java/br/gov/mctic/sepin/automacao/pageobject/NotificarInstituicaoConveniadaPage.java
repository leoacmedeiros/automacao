package br.gov.mctic.sepin.automacao.pageobject;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import br.gov.mctic.sepin.automacao.core.AbstractPageObject;

public class NotificarInstituicaoConveniadaPage extends AbstractPageObject {

	// Clicar no menu RDA
	@FindBy(xpath = "//button/span/div/span[contains(text(),'RDA')]")
	private WebElement clicarBotaoRDA;

	public void clicarBotaoRDA() {
		clicarBotaoRDA.click();
	}

	// Clicar na op��o "Projeto Conveniado"
	@FindBy(xpath = "//span[contains(text(),'Projeto Conveniado')]")
	private WebElement clicarProjetoConveniado;

	public void clicarProjetoConveniado() {
		clicarProjetoConveniado.click();
	}

	// Clicar em Notificar Institui��o
	@FindBy(xpath = "//span[contains(text(),'Notificar')]")
	private WebElement clicarNotificarInstituicao;

	public void clicarNotificarInstituicao() {
		clicarNotificarInstituicao.click();
	}

	// Inseir a Sigla
	@FindBy(xpath = "//input[@formcontrolname = 'sigla']")
	private WebElement inserirSigla;

	public void inserirSigla(String sigla) {
		inserirSigla.sendKeys(sigla);
	}

	// Inserir o nome
	@FindBy(xpath = "//input[@formcontrolname = 'nome']")
	private WebElement inserirNome;

	public void inserirNome(String nome) {
		inserirNome.sendKeys(nome);
	}

	// Selecionar a Regi�o
	@FindBy(xpath = "//mat-select[@ng-reflect-name='regiao']")
	private WebElement selecionarRegiao;

	public void selecionarRegiao() {
		selecionarRegiao.click();
	}

	// Inserir a regi�o
	@FindBy(xpath = "//span[contains(text(),'SUDENE')]")
	private WebElement inserirRegiao;

	public void inserirRegiao() {
		inserirRegiao.click();
	}

	// Selecionar Institui��o
	@FindBy(xpath = "//mat-select[@formcontrolname='instituicao']//div")
	private WebElement selecionarInstituicao;

	public void selecionarInstituicao() {
		selecionarInstituicao.click();
	}

	// Inserir Instituicao
	@FindBy(xpath = "//span[contains(text(),'C.E.S.A.R Incubadora')]")
	private WebElement inserirInstituicao;

	public void inserirInstituicao() {
		inserirInstituicao.click();
	}

	// Inserir empresa encubadora
	@FindBy(xpath = "//input[@formcontrolname = 'descricaoEmpresa']")
	private WebElement inserirEncubadora;

	public void inserirEncubadora(String encubadora) {
		inserirEncubadora.sendKeys(encubadora);
	}

	// Inserir data inicial
	@FindBy(xpath = "//input[@formcontrolname = 'dataInicioVinculo']")
	private WebElement inserirDataInicial;

	public void inserirDataInicial(String dataInicial) {
		inserirDataInicial.sendKeys(dataInicial);
	}

	// Inserir data Final
	@FindBy(xpath = "//input[@formcontrolname = 'dataFimVinculo']")
	private WebElement inserirDataFinal;

	public void inserirDataFinal(String dataFinal) {
		inserirDataFinal.sendKeys(dataFinal);
	}

	// Selecionando tipo do projeto=TP
	@FindBy(xpath = "//app-select-tipos-projeto[@controlname='tipoProjeto']/..")
	private WebElement selecionarTP;

	public void selecionarTP() {
		selecionarTP.click();
	}

	// Inserir o tipo de pojeto com "Hardware"
	@FindBy(xpath = "//span[contains(text(),'Hardware')]")
	private WebElement inserirTP;

	public void inserirTP() {
		inserirTP.click();
	}

	// Clicar na op��o "Sim"
	@FindBy(xpath = "//label[div[contains(text(),' Sim ')]]/div")
	private List<WebElement> clicarSim;

	public void clicarSim() {
		clicarSim.get(0).click();
		clicarSim.get(0).click();
	}

	// Clicar no "Enviar"
	@FindBy(xpath = "//span[contains(text(),' Enviar')]")
	private WebElement clicarEnviar;

	public void clicarEnviar() {
		clicarEnviar.click();
	}

	// Consultar Institui��o Conveniada
	

	// Inserir a identifica��o
	@FindBy(xpath = "//input[@formcontrolname = 'identificacao']")
	private WebElement inserirIDConsultar;

	public void inserirIDConsultar(String id) {
		inserirIDConsultar.sendKeys(id);
	}

	// Inserir a sigla
	@FindBy(xpath = "//input[@formcontrolname = 'sigla']")
	private WebElement inserirSiglaConsultar;

	public void inserirSiglaConsultar(String sigla) {
		inserirSiglaConsultar.sendKeys(sigla);
	}

	// Inserir o nome
	@FindBy(xpath = "//input[@formcontrolname = 'nome']")
	private WebElement inserirNomeConsultar;

	public void inserirNomeConsultar(String nome) {
		inserirNomeConsultar.sendKeys(nome);
	}

	// Inserir data incial
	@FindBy(xpath = "//input[@formcontrolname = 'dataInicio']")
	private WebElement inserirDataInicioConsultar;

	public void inserirDataInicioConsultar(String dataInicio) {
		inserirDataInicioConsultar.sendKeys(dataInicio);
	}

	// Inserir data fim
	@FindBy(xpath = "//input[@formcontrolname = 'dataFim']")
	private WebElement inserirDataFimConsultar;

	public void inserirDataFimConsultar(String dataFim) {
		inserirDataFimConsultar.sendKeys(dataFim);
	}

	// Selecionar Tipo do Projeto = TP
	@FindBy(xpath = "//mat-select[contains(text(), '')]/../..")
	private WebElement selecionarTPConsultar;

	public void selecionarTPConsultar() {
		selecionarTPConsultar.click();
	}

	// Inserindo Tipo do Projeto = TP
	@FindBy(xpath = "//span[contains(text(), 'Hardware')]")
	List<WebElement> inserirTPConsultar;

	public void inserirTPConsultar() {
		inserirTPConsultar.get(0).click();
	}

	// Inserir institui��o
	@FindBy(xpath = "//input[@formcontrolname='nomeInstituicao']")
	private WebElement inserirInstituicaoConsultar;

	public void inserirInstituicaoConsultar(String instituicao) {
		inserirInstituicaoConsultar.sendKeys(instituicao);
	}

	// clicar na institui��o C.E.S.A.R Incubadora - Incubadora do Centro de Estudos
	@FindBy(xpath = "//span[contains(text(), 'C.E.S.A.R Incubadora - Incubadora do Centro de Estudos e Sistemas Avan�ados do Recife')]")
	private WebElement clicarInstituicaoCESAR;

	public void clicarInstituicaoCESAR() {
		clicarInstituicaoCESAR.click();
	}

	// acionar consultar
	@FindBy(xpath = "//button[span[contains(text(),'Consultar')]]")
	private WebElement clicarConsultar;

	public void clicarConsultar() {
		clicarConsultar.click();
	}

	// Excluir Institui��o conveniada

	// Acionar angrenagem
	@FindBy(xpath = "//mat-icon[contains(text(), 'settings')]/..")
	List<WebElement> acionarEngrenagem;

	public void acionarEngrenagem() {
		acionarEngrenagem.get(0).click();
	}

	// Clicar em Exluir
	@FindBy(xpath = "//span[contains(text(), 'Excluir')]")
	private WebElement clicarDelete;

	public void clicarDelete() {
		clicarDelete.click();
	}

	// Confirmar a exclus�o
	@FindBy(xpath = "//span[contains(text(), 'Sim')]/..")
	private WebElement clicarSimExcluir;

	public void clicarSimExcluir() {
		clicarSimExcluir.click();
	}

	// Visualizar projeto conveniado

	// Acionar engrenagem
	@FindBy(xpath = "//mat-icon[contains(text(),'settings')]/../..")
	private List<WebElement> clicarEngrenagem;

	public void clicarEngrenagem() {
		clicarEngrenagem.get(0).click();
	}

	// Clicar em visualizar
	@FindBy(xpath = "//mat-icon[contains(text(),'visibility')]")
	private WebElement clicarVisualizar;

	public void clicarVisualizar() {
		clicarVisualizar.click();
	}
}
