package br.gov.mctic.sepin.automacao.cenario.cadastrarProjetoProprio;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadstrarProjetoProprioPage;

public class AlterarProjetoProprio extends AbstractCenario {

	@Test
	
	public void EditarPojetoProprio() {

    //acessarMenu("RDA", "Projeto Pr�prio");
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selecionarOpcao();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selcionarBotao("Editar");
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).informarSigla("TST1");
	Em(CadstrarProjetoProprioPage.class).informarNome("TESTE1");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).informarDataIncio("03/02/2018");
	Em(CadstrarProjetoProprioPage.class).informarDataFim("02/02/2020");
	Em(CadstrarProjetoProprioPage.class).SelecionarcomboTipo();
	Em(CadstrarProjetoProprioPage.class).selcionaropcao("Hardware");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelcionarRadio("Sim");
	Em(CadstrarProjetoProprioPage.class).selecionarclose();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).informarCPF("020.431.553-00 ");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelcionarRadio(" Celular ");
	Em(CadstrarProjetoProprioPage.class).informarTelefone("61995912930");
	Em(CadstrarProjetoProprioPage.class).informarEmail("Kelly1.cavalcante@ctis.com");
	Em(CadstrarProjetoProprioPage.class).selcionarCheck("Na Empresa");
	Em(CadstrarProjetoProprioPage.class).selcionarCheck("Na Institui��o");
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelecionarRadioAbangenciaDesenvolvimento(" Novo para a empresa, mas existente no mercado nacional; ");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).SelecionarRadioAbangenciaDesenvolvimento(" Aprimoramentos a partir de algo existente; ");
	Em(CadstrarProjetoProprioPage.class).propriedadeintelectualRadio("N�o");
	Em(CadstrarProjetoProprioPage.class).possuiPublicacaoRadio("N�o");
	Em(CadstrarProjetoProprioPage.class).limparArea();
	Em(CadstrarProjetoProprioPage.class).informaArea("J.61");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selcionarCheck("II - trabalho sistem�tico utilizando o conhecimento");
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selcionarBotao("Avan�ar");
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).informarObjetivo("Informar Objetivo");
	Em(CadstrarProjetoProprioPage.class).informarDescricao("Informar Descri��o");
	Em(CadstrarProjetoProprioPage.class).informarResultado("Informar Resultado");
	Em(CadstrarProjetoProprioPage.class).selcionarBotao(" Salvar e avan�ar ");
	aguardarCarregamento();
	aguardarCarregamento();
	aguardarCarregamento();
	aguardarCarregamento();
	Em(CadstrarProjetoProprioPage.class).selcionarBotao("Concluir");
	//finalizarNavegador();

	}
}