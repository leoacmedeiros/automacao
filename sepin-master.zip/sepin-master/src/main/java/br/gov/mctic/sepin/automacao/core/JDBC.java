package br.gov.mctic.sepin.automacao.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC{
	private static Connection conexao = null;
	
	public static Connection getConnection() {
		
		if (conexao == null) {
			String servidor = PropriedadeUtils.get("db_servidor");
			String schema = PropriedadeUtils.get("db_schema");
			String user = PropriedadeUtils.get("db_user");
			String password = PropriedadeUtils.get("db_password");
				
			try {
				 conexao = DriverManager.getConnection(
						"jdbc:sqlserver://"+servidor+":1433;DatabaseName="+schema, user, password);
		

			} catch (SQLException e) {
				throw new RuntimeException("N�o foi poss�vel conectar ao banco: " + e.getMessage());
			}
		}
		return conexao;
	}

	public static void executeSelect(String coluna, String tabela) throws SQLException {
		Statement state = getConnection().createStatement();
		ResultSet result = state.executeQuery("select " + coluna + " from sepin." + tabela);
		while (result.next()) {
			System.out.println(result.getString(1));
		}
		state.close();
		System.out.println("A conex�o com o banco foi finalizada: " + state.isClosed());
	}

	public static void executeUpdate(String update) throws SQLException {
		Statement state = getConnection().createStatement();
		int result = state.executeUpdate(update);
		if (result > 0) {
			System.out.println("Altera��o realizada com sucesso");
		} else {
			System.out.println("Update n�o executado");
		}
		state.close();
		System.out.println("A conex�o com o banco foi finalizada: " + state.isClosed());
	}

	public static void executeDelete(String delete) throws SQLException {
		Statement state = getConnection().createStatement();
		boolean result = state.execute(delete);
		state.close();
		System.out.println("A conex�o com o banco foi finalizada: " + state.isClosed());
	}
	
	public static void execute(String sql)throws SQLException {
		Statement state = getConnection().createStatement();
		boolean result = state.execute(sql);
		state.close();
		System.out.println("A conex�o com o banco foi finalizada: " + state.isClosed());
	}
}
