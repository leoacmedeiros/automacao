package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoBrutoImportacaoIncentivo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ IncluirFaturamentoBrutoImportacoesIncentivo.class, AlterarFaturamentoBrutoImportacoesIncentivo.class })
public class SuiteCadastrarFaturamentoBrutoImportacaoIncentivo {

}
