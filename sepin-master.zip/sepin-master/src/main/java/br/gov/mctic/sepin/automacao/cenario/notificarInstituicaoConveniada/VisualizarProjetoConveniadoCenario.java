package br.gov.mctic.sepin.automacao.cenario.notificarInstituicaoConveniada;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.NotificarInstituicaoConveniadaPage;

public class VisualizarProjetoConveniadoCenario extends AbstractCenario {
	@Test
	public void VisualizarProjetoConveniadoPage() {
		
		selecionarEmpresa("04.277.850/0001-92");
		acessarMenu("RDA","Projeto Conveniado");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarEngrenagem();
		aguardarCarregamento();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarVisualizar();
		aguardarCarregamento();
	}

}
