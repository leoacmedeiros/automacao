package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoBrutoImportacaoIncentivo;

import static org.junit.Assert.*;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.pageobject.CadastrarFaturamentoBrutoImportacaoIncentivoPage;
import br.gov.mctic.sepin.automacao.core.AbstractCenario;


public class AlterarFaturamentoBrutoImportacoesIncentivo extends AbstractCenario{

	@Test
	public void ct086_AlterarncluirFaturamentoBrutoImportacoesIncentivo(){
		acessarMenu("RDA","RDA", "Faturamento Bruto");
		aguardarCarregamento();
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherTotalEmpresa("30000000999");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherTotalSoftware("1600000888");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherTotalServicosTI("1600000888");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesTotaisEmpresa("1800000777");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesTotaisProdutosIncentivados("1900000666");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesSoftware("2000000555");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesServicos("2100000444");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesTotaisEmpresa("2200000333");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesTotaisInsumos("2300000222");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesProdutosAcabados("2500000111");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesRemessasSoftware("2600000999");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesRemessasServicos("270000999");
		aguardarCarregamento();
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).acionarSalvarFaturamentoBruto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).mensagemSucessoCadastrarAlterar("Opera��o realizada com sucesso!");
		finalizarNavegador();

	}

}
