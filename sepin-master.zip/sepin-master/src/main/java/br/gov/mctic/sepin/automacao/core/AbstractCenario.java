package br.gov.mctic.sepin.automacao.core;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public abstract class AbstractCenario {

	protected <T> T Em(Class<T> classe) {
		return PageFactory.initElements(WDS.get(), classe);
	}

	protected void selecionarInstituicao(String cnpj) {
		selecionarInstituicaoEmpresa(cnpj, 0);
	}

	protected void selecionarEmpresa(String cnpj) {
		selecionarInstituicaoEmpresa(cnpj, 1);
	}

	private void selecionarInstituicaoEmpresa(String cnpj, int tipo) {
		if (tipo == 0) {
			acessarMenu("Selecionar Institui��o");
		} else if (tipo == 1) {
			acessarMenu("Seleciona Empresa");
		} else {
			throw new RuntimeException("Tipo \"" + tipo + "\" inv�lido.");
		}
		WDS.get().findElement(By.xpath(("//mat-radio-button/label/div[contains(text(),'" + cnpj + "')]/../..")))
				.click();
		WDS.get().findElement(By.xpath(("//button/span[text()='Confirmar']/.."))).click();
		aguardarCarregamento();
	}

	protected void acessarMenu(String... menus) {
		aguardarCarregamento();
		for (int i = 0; i < menus.length; i++) {
			WDS.get().findElement(By.xpath("//span[text()='" + menus[i] + "']/../../..")).click();
		}
		aguardarCarregamento();
	}

	protected void aguardarCarregamento() {
		WDS.delay(1000);
		WDS.getWait().until(ExpectedConditions.invisibilityOf(WDS.get().findElement(By.tagName("mctic-loading"))));
		WDS.delay(1000);
	}

	protected void botaoAvancar(String botao) {
		WDS.get().findElement(By.xpath("//button//span[contains(text(),'" + botao + "')]")).click();
	}

	protected void finalizarNavegador() {
		WDS.driver.close();
		WDS.matarProcessoWindows();

	}

	protected void exibeMensagem(String mensagemEsperada) {
		WebElement campoMensagem = WDS.get().findElement(By.xpath("//div[@role='alertdialog']"));
		Assert.assertEquals(mensagemEsperada, campoMensagem.getText());
	}

}
