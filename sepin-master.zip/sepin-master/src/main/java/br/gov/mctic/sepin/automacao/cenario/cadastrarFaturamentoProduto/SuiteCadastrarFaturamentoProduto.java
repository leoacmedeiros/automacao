package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoProduto;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ IncluirFaturamentoProduto.class, AlterarFaturamentoProduto.class, VisualizarFaturamentoProduto.class })
public class SuiteCadastrarFaturamentoProduto {

}
