package br.gov.mctic.sepin.automacao.cenario.cadastrarProjetoProprio;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.core.WDS;
import br.gov.mctic.sepin.automacao.pageobject.CadstrarProjetoProprioPage;

public class ExcluirProjetoProprio extends AbstractCenario {
	
	@Test
	public void excluirProjetoProprio() {
		
		//aguardarCarregamento();
		//acessarMenu("RDA", "Projeto Pr�prio");
		Em(CadstrarProjetoProprioPage.class).selecionarOpcao();
		aguardarCarregamento();
		Em(CadstrarProjetoProprioPage.class).selcionarBotao("Excluir");
		aguardarCarregamento();
		Em(CadstrarProjetoProprioPage.class).selcionarBotao("Sim");
		aguardarCarregamento();
		Em(CadstrarProjetoProprioPage.class).validarMensagemSucesso("Opera��o realizada com sucesso!");
		//finalizarNavegador();
	}
}
