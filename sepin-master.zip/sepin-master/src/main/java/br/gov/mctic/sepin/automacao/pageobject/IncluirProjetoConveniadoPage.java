package br.gov.mctic.sepin.automacao.pageobject;

import java.sql.SQLException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import br.gov.mctic.sepin.automacao.core.AbstractPageObject;
import br.gov.mctic.sepin.automacao.core.JDBC;
import br.gov.mctic.sepin.automacao.core.WDS;

public class IncluirProjetoConveniadoPage extends AbstractPageObject {
	public void acessarProjeto(String nomeProjeto, String acao) {
		aguardarCarregamento();
		WDS.get().findElement(By.xpath("//td[text()='" + nomeProjeto + "']/../td[6]/button")).click();
		WDS.delay(500);
		WDS.get().findElement(By.xpath("//span[text()='" + acao + "']/..")).click();
	}

	@FindBy(id = "mat-input-5")
	private WebElement cpf;

	@FindBy(xpath = "//button[@appresponsavelpreenchimento]")
	private WebElement removeCPF;

	public void informarResponsavelProjeto(String cpfResponsavel) {
		cpf.sendKeys(cpfResponsavel);
		cpf.sendKeys(Keys.TAB);
	}

	public void alterarResponsavelProjeto(String cpfResponsavel) {
		aguardarCarregamento();
		removeCPF.click();
		cpf.sendKeys(cpfResponsavel);
		cpf.sendKeys(Keys.TAB);
	}

	public void inputResponsavelProjeto(String campo, String valor) {
		WebElement campoInput = WDS.get()
				.findElement(By.xpath("//app-responsavel-projeto//input[@formcontrolname='" + campo + "']"));
		campoInput.sendKeys(valor);
	}

	public void informarTelefone(String tipo, String campo, String numeroTelefone) {
		radio(tipo);
		aguardarCarregamento();
		inputResponsavelProjeto(campo, numeroTelefone);
	}

	@FindBy(xpath = "//app-responsavel-projeto//input[@formcontrolname='email']")
	private WebElement limparEmail;

	public void informarEmail(String campo, String email) {
		boolean vazio = limparEmail.toString().isEmpty();
		aguardarCarregamento();
		if (vazio == false) {
			limparEmail.clear();
			inputResponsavelProjeto(campo, email);
		} else {
			inputResponsavelProjeto(campo, email);
		}

	}

	public void selecionarAlcance(String alcance) {
		checkbox(alcance);
	}

	public void selecionarAbrangencia(String abrangencia) {
		radio(abrangencia);
		radio(abrangencia);
	}

	public void selecionarDesenvoltimento(String desenvolvimento) {
		radio(desenvolvimento);

	}

	@FindBy(xpath = "//input[@formcontrolname='atividadeEconomica']")
	private WebElement limparAtividadeEconomica;

	public void atividadeEconomica(String campo, String valor) {
		boolean vazio = limparAtividadeEconomica.toString().isEmpty();
		if (vazio == false) {
			limparAtividadeEconomica.clear();
			input(campo, valor);
			option(valor);
		} else {
			input(campo, valor);
			option(valor);
		}

	}

	@FindBy(xpath = "//app-area-aplicacao-projeto//mat-radio-button")
	private List<WebElement> areaAplicacao;

	public void gerouProPriedadeIntelectualSim() {
		gerouPropriedadeIntelectual(0);
		gerouPropriedadeIntelectual(0);
	}

	public void gerouProPriedadeIntelectualNao() {
		gerouPropriedadeIntelectual(1);
		gerouPropriedadeIntelectual(1);
	}

	private void gerouPropriedadeIntelectual(Integer opcao) {
		if (opcao == 0) {
			areaAplicacao.get(0).click();
		} else if (opcao == 1) {
			areaAplicacao.get(1).click();
		} else {
			throw new RuntimeException("Op��o \"" + opcao + "\" inv�lida.");
		}
	}

	public void projetoPossuiPublicacaoSim() {
		projetoPossuiPublicacao(0);
		projetoPossuiPublicacao(0);
	}

	public void projetoPossuiPublicacaoNao() {
		projetoPossuiPublicacao(1);
		projetoPossuiPublicacao(1);
	}

	private void projetoPossuiPublicacao(Integer opcao) {
		if (opcao == 0) {
			areaAplicacao.get(2).click();
		} else if (opcao == 1) {
			areaAplicacao.get(3).click();
		} else {
			throw new RuntimeException("Op��o \"" + opcao + "\" inv�lida.");
		}
	}

	public void selecionarArtigo(String artigo) {
		checkbox(artigo);
	}

	public void informarObjetivo(String campo, String valor) {
		textArea(campo, valor);
	}

	public void informarDescricaoEtapas(String campo, String valor) {
		textArea(campo, valor);
	}

	public void informarResultadoObtido(String campo, String valor) {
		textArea(campo, valor);
	}

	public void custoIncorrido(String valor) {
		inputDispendioRepassado("custoIncorrido", valor);
	}

	public void valorTotalRepassadoInstituicao(String valor) {
		inputDispendioRepassado("valorRepassado", valor);
	}

	public void valorAntecipadoProximoAno(String valor) {
		inputDispendioRepassado("valorAntecipadoProximoAno", valor);
	}

	public void valorAntecipadoAnoAnterior(String valor) {
		inputDispendioRepassado("valorAntecipadoAnoAnterior", valor);
	}

	@FindBy(xpath = "//span[contains(text(),' Informar Propriedade Intelectual ')]/..")
	private WebElement informarPropriedadeIntelectual;

	@FindBy(xpath = "//mat-toolbar//span[contains(text(),'Cadastrar Propriedade Intelectual')]")
	private WebElement telaInformarPropriedadIntelectual;

	@FindBy(xpath = "//div/app-radio-sim-nao[@controlname='gerouPropriedadeIntelectual']")
	private WebElement gerouPropriedade;

	public void informarPropriedadeIntelectual() {
		aguardarCarregamento();
		if (gerouPropriedade.isDisplayed()) {
			gerouProPriedadeIntelectualSim();
			informarPropriedadeIntelectual.click();
			telaInformarPropriedadIntelectual.isDisplayed();
			System.out.println("A funcionalidade " + telaInformarPropriedadIntelectual.getText()
					+ " est� disponivel no cadastro de projeto conveniado");

		} else {
			throw new RuntimeException("A op��o gerou propriedade n�o est� disponivel");
		}
		aguardarCarregamento();

	}

	public String recuperarIdentificacao(String nomeProjeto) {
		WebElement campoIdentificacao = WDS.get().findElement(By.xpath("//td[text()='" + nomeProjeto + "']/../td[2]"));
		String id = campoIdentificacao.getText();
		return id;
	}

	public void limparDadosDeTeste(String nomeProjeto) throws SQLException {
		String id = recuperarIdentificacao(nomeProjeto);
		JDBC.executeDelete("delete from sepin.TBComplementoProjeto where IDProjeto = " + id);
		JDBC.executeDelete("delete from sepin.TBResponsavelProjeto where IDProjeto = " + id);
		JDBC.executeDelete("delete from sepin.TBProjetoAlcance where IDProjeto = " + id);
		JDBC.executeDelete("delete from sepin.TBProjetoArtigo where IDProjeto = " + id);
		JDBC.executeDelete("delete from sepin.TBDispendioRepassado where IDProjeto = " + id);

	}

}