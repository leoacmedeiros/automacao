package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoProduto;

import org.junit.Test;
import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadastrarFaturamentoProdutoPage;


public class AlterarFaturamentoProduto extends AbstractCenario{

	@Test
	public void ct085_AlterarFaturamentoProduto() {
		
		//acessarMenu("RDA","Faturamento do Produto");
		aguardarCarregamento();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimLinha1();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarAcoesLinha1();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimAbaProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarProximoAbaProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).preencherFaturamentoBruto("10000000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherExportacoes("20000000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherVendasZFM("30000000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherQuantidadeProduzida("500");
		Em(CadastrarFaturamentoProdutoPage.class).preencherIPI("400000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherPISCofins("500000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherICMS("600000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherAquisicoesBens("700000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherDevolucoes("800000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherIncentivoIPI("900000");
		Em(CadastrarFaturamentoProdutoPage.class).preencherIncentivoIMCS("900000");
		Em(CadastrarFaturamentoProdutoPage.class).acionarProximoAbaFaturamento();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarOpcaoSimAbaTrocaPPB();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarPortariaPPB("101");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).preencherPercentualPortaria("5");
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherProjetoConveniado("100000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherProjetoProprio("100000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherFNDCT("100000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).selecionarCheckPreencherPPI("50000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).acionarSalvarFaturamentoProduto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoProdutoPage.class).mensagemSucessoCadastrarAlterar("Opera��o realizada com sucesso!");
				
		
	}

}
