package br.gov.mctic.sepin.automacao.pageobject;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import br.gov.mctic.sepin.automacao.core.AbstractPageObject;
import br.gov.mctic.sepin.automacao.core.WDS;

public class CadastrarFaturamentoBrutoImportacaoIncentivoPage extends AbstractPageObject{

	
	/* In�cio IncluirFaturamentoBrutoImportacoesIncentivo */
	
	@FindBy(xpath="//app-currency[@controlname='valorTotalEmpresa']//input")
	private WebElement insereValorTotalEmpresa;
	
	public void preencherTotalEmpresa(String valorTotalEmpresa) {
		insereValorTotalEmpresa.clear();
		insereValorTotalEmpresa.sendKeys(valorTotalEmpresa);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorTotalSoftware']//input")
	private WebElement insereValorSoftware;
		
	public void preencherTotalSoftware(String valorSoftware) {
		insereValorSoftware.clear();
		insereValorSoftware.sendKeys(valorSoftware);
		
	}
	
	@FindBy(xpath="//app-currency[@controlname='valorTotalServicosTI']//input")
	private WebElement insereValorTotalServicosTI;
	
	public void preencherTotalServicosTI(String valorTotalServicosTI) {
		insereValorTotalServicosTI.clear();
		insereValorTotalServicosTI.sendKeys(valorTotalServicosTI);
		
	}
	
	@FindBy(xpath="//app-currency[@controlname='valorExportacaoTotalEmpresa']//input")
	private WebElement insereValorExportacoesTotaisEmpresa;

	public void preencherExportacoesTotaisEmpresa(String valorExportacoesTotaisEmpresa) {
		insereValorExportacoesTotaisEmpresa.clear();
		insereValorExportacoesTotaisEmpresa.sendKeys(valorExportacoesTotaisEmpresa);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorExportacaoTotalProdutosIncentivados']//input")
	private WebElement insereValorExportacoesTotalProdutosIncentivados;
	
	public void preencherExportacoesTotaisProdutosIncentivados(String valorExportacoesTotalProdutosIncentivados) {
		insereValorExportacoesTotalProdutosIncentivados.clear();
		insereValorExportacoesTotalProdutosIncentivados.sendKeys(valorExportacoesTotalProdutosIncentivados);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorExportacaoSoftware']//input")
	private WebElement insereValorExportacoesSoftware;
	
	public void preencherExportacoesSoftware(String valorExportacoesSoftware) {
		insereValorExportacoesSoftware.clear();
		insereValorExportacoesSoftware.sendKeys(valorExportacoesSoftware);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorExportacaoServicos']//input")
	private WebElement insereValorExportacoesServico;
	
	public void preencherExportacoesServicos(String valorExportacoesServico) {
		insereValorExportacoesServico.clear();
		insereValorExportacoesServico.sendKeys(valorExportacoesServico);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorImportacaoTotalEmpresa']//input")
	private WebElement insereValorImportacoesTotaisEmpresa;
	
	public void preencherImportacoesTotaisEmpresa(String valorImportacoesTotaisEmpresa) {
		insereValorImportacoesTotaisEmpresa.clear();
		insereValorImportacoesTotaisEmpresa.sendKeys(valorImportacoesTotaisEmpresa);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorImpotacaoTotalInsumos']//input")
	private WebElement insereValorImportacaoTotaisInsumos;
	
	public void preencherImportacoesTotaisInsumos(String valorImportacaoTotaisInsumos) {
		insereValorImportacaoTotaisInsumos.clear();
		insereValorImportacaoTotaisInsumos.sendKeys(valorImportacaoTotaisInsumos);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorImportacaoProdutosRevenda']//input")
	private WebElement insereValorImportacoesProdutosAcabados;
	
	public void preencherImportacoesProdutosAcabados(String valorImportacoesProdutosAcabados) {
		insereValorImportacoesProdutosAcabados.clear();
		insereValorImportacoesProdutosAcabados.sendKeys(valorImportacoesProdutosAcabados);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorImportacaoSoftware']//input")
	private WebElement insereValorImportacoesRemessasSoftware;
	
	public void preencherImportacoesRemessasSoftware(String valorImportacoesRemessasSoftware) {
		insereValorImportacoesRemessasSoftware.clear();
		insereValorImportacoesRemessasSoftware.sendKeys(valorImportacoesRemessasSoftware);
		
	}

	@FindBy(xpath="//app-currency[@controlname='valorImportacaoServicos']//input")
	private WebElement insereValorImportacoesRemessasServicos;
	
	public void preencherImportacoesRemessasServicos(String valorImportacoesRemessasServico) {
		insereValorImportacoesRemessasServicos.clear();
		insereValorImportacoesRemessasServicos.sendKeys(valorImportacoesRemessasServico);
		
	}

	@FindBy(xpath="//button//span[contains(text(),'Salvar')]")
	private WebElement botaoSalvarFaturamentoBruto;
	
	public void acionarSalvarFaturamentoBruto() {
		botaoSalvarFaturamentoBruto.click();
		
	}
	
	@FindBy(xpath="//div[@class='toast-message ng-star-inserted']")
	private WebElement mensagemSucessoCadastro;
	
	public void mensagemSucessoCadastrarAlterar(String mensagemSucesso) {
		try {
			Assert.assertEquals(mensagemSucesso, mensagemSucessoCadastro.getText());
			System.out.println("Cadastro/Altera��o realizado com sucesso!");
			
		}catch(AssertionError e){
			System.out.println("ERRO!!! Cadastro/Altera��o n�o realizado!");
			
		}
		
			
	}

	
	/* Fim IncluirFaturamentoBrutoImportacoesIncentivo */

}
