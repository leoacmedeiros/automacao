package br.gov.mctic.sepin.automacao.cenario.cadastrarFaturamentoBrutoImportacaoIncentivo;

import org.junit.Test;
import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.CadastrarFaturamentoBrutoImportacaoIncentivoPage;



public class IncluirFaturamentoBrutoImportacoesIncentivo extends AbstractCenario{

	@Test
	public void ct086_IncluirFaturamentoBrutoImportacoesIncentivo() {
		acessarMenu("RDA","Faturamento Bruto");
		aguardarCarregamento();
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherTotalEmpresa("20000000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherTotalSoftware("1500000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherTotalServicosTI("1500000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesTotaisEmpresa("1700000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesTotaisProdutosIncentivados("1600000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesSoftware("1500000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherExportacoesServicos("1400000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesTotaisEmpresa("1300000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesTotaisInsumos("1200000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesProdutosAcabados("1100000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesRemessasSoftware("1000000000");
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).preencherImportacoesRemessasServicos("900000000");
		aguardarCarregamento();
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).acionarSalvarFaturamentoBruto();
		aguardarCarregamento();
		Em(CadastrarFaturamentoBrutoImportacaoIncentivoPage.class).mensagemSucessoCadastrarAlterar("Opera��o realizada com sucesso!");
	}

}
