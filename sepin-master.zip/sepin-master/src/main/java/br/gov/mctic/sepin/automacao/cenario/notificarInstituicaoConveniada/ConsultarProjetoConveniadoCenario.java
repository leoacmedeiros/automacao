package br.gov.mctic.sepin.automacao.cenario.notificarInstituicaoConveniada;

import org.junit.Test;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.pageobject.NotificarInstituicaoConveniadaPage;

public class ConsultarProjetoConveniadoCenario extends AbstractCenario {
	@Test
	public void NotificarInstituicaConveniada() {

		selecionarEmpresa("00.954.716/0002-09");
		acessarMenu("RDA","Projeto Conveniado");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirIDConsultar("26");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirSiglaConsultar("TST002");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirNomeConsultar("Teste Geovanne 616");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirDataInicioConsultar("01/01/2019");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirDataFimConsultar("01/12/2019");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).selecionarTPConsultar();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirTPConsultar();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).inserirInstituicaoConsultar(
				"C.E.S.A.R Incubadora - Incubadora do Centro de Estudos e Sistemas Avan�ados do Recife");
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarInstituicaoCESAR();
		aguardarCarregamento();
		Em(NotificarInstituicaoConveniadaPage.class).clicarConsultar();
	}
}
