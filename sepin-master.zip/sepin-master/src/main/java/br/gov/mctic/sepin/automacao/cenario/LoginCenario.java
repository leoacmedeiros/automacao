package br.gov.mctic.sepin.automacao.cenario;

import br.gov.mctic.sepin.automacao.core.AbstractCenario;
import br.gov.mctic.sepin.automacao.core.PropriedadeUtils;
import br.gov.mctic.sepin.automacao.pageobject.LoginPage;

public class LoginCenario extends AbstractCenario {

    public void realizarLogin() {
        Em(LoginPage.class).informarUsuario(PropriedadeUtils.get("usuario"));
        Em(LoginPage.class).informarSenha(PropriedadeUtils.get("senha"));
        Em(LoginPage.class).solicitarLogin();
    }

}
